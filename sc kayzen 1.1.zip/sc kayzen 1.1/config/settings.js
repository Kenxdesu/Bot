const fs = require('fs')
const chalk = require('chalk')
// EDIT DISINI
//NOTE ' EMOTIKON ITU JNGAN DI HAPUS 
//YANG GA SUBREK GW DOAIN EROR👺👺
global.owner = ['6289635946324',"6289635946324"]// no lu
global.creAtor = "6289635946324@s.whatsapp.net" //Jangan Ganti Tar Error
global.load = 'https://youtube.com/@kayzenhost13'//bisa gnti ke lgc/yt
global.namestore = 'Kayzen'//ubah aja jadi nama store lu
global.ttname = 'KayzenOfc'
global.packname = 'Kayzen'//ubah aja ini pack name stiker
global.author = 'KayzenOfc'//ubah aja ini author stiker
global.delayy = 5000;//set delayny saran aja minim 3000
global.prefix = ['#','$','.','/','+','-']//gausah di apapain

global.mess = {
creator: '_*LU BUKAN BANG Kayzen, GAUSAH SO ASIK*_',
load: '*Currently loading*\n_*[■■■■■■■■■□] 90%*_',
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.yellowBright(`Update File Terbaru ${__filename}`))
delete require.cache[file]
require(file)
})